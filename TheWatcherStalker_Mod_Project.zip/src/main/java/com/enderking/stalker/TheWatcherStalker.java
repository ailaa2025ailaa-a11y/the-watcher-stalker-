package com.enderking.stalker;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TheWatcherStalker implements ModInitializer {
	public static final String MOD_ID = "the_watcher_stalker";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		// The scares live in the built-in data pack (data/enderhorror)
		// and the jumpscare face in the built-in resource pack (assets/enderhorror).
		LOGGER.info("The Watcher Stalker loaded");
	}
}
