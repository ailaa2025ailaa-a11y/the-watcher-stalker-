execute at @s run function enderhorror:scare/jumpscare
