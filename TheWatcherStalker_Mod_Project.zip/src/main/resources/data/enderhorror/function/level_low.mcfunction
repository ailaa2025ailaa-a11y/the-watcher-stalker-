scoreboard players set #level eh_level 1
tellraw @s {text:"Horror level: LOW (rare scares)",color:"yellow"}
