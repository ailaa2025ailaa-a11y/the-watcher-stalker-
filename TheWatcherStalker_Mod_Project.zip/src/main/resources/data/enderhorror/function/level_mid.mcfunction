scoreboard players set #level eh_level 2
tellraw @s {text:"Horror level: MEDIUM",color:"gold"}
