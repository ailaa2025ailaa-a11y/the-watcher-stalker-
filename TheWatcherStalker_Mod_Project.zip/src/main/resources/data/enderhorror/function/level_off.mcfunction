scoreboard players set #level eh_level 0
tellraw @s {text:"Horror OFF",color:"gray"}
kill @e[type=minecraft:enderman,tag=eh_hollow]
kill @e[type=minecraft:enderman,tag=eh_watcher]
