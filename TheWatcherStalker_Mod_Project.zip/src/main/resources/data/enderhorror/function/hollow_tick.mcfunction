scoreboard players add @s eh_life 1
scoreboard players add @s eh_beat 1
execute if score @s eh_life matches 1 run data merge entity @s {AngerTime:7000}
execute if score @s eh_life matches 1 run data modify entity @s AngryAt set from entity @p UUID
execute if score @s eh_life matches 1 run playsound minecraft:entity.enderman.stare hostile @a[distance=..60] ~ ~ ~ 3 0.4
particle minecraft:smoke ~ ~1.5 ~ 0.2 0.8 0.2 0.01 3
execute if score @s eh_beat matches 30.. run function enderhorror:hollow_beat
execute if score @s eh_life matches 6000.. run function enderhorror:hollow_vanish
