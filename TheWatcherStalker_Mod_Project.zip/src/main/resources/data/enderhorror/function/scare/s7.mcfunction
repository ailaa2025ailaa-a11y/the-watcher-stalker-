playsound minecraft:ambient.cave ambient @s ~ ~ ~ 2 0.5
playsound minecraft:entity.elder_guardian.curse ambient @s ~ ~ ~ 0.8 0.5
