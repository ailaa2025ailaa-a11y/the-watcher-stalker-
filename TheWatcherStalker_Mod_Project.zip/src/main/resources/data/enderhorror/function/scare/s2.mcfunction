execute store result score @s eh_msg run random value 1..6
execute if score @s eh_msg matches 1 run tellraw @s {text:"<???> i can see you",color:"dark_red"}
execute if score @s eh_msg matches 2 run tellraw @s {text:"<???> don't look behind you",color:"dark_red"}
execute if score @s eh_msg matches 3 run tellraw @s {text:"<???> you are not alone in this world",color:"dark_red"}
execute if score @s eh_msg matches 4 run tellraw @s {text:"<???> turn around",color:"dark_red"}
execute if score @s eh_msg matches 5 run tellraw @s {text:"<???> why did you come back",color:"dark_red"}
execute if score @s eh_msg matches 6 run tellraw @s {text:"<???> it is getting closer",color:"dark_red"}
playsound minecraft:ambient.cave ambient @s ~ ~ ~ 2 0.7
