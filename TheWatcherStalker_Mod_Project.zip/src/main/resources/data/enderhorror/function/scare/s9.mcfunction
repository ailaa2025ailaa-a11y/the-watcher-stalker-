execute positioned ^ ^ ^-25 run summon minecraft:enderman ~ ~ ~ {Silent:1b,PersistenceRequired:1b,Tags:["eh_hollow"],CustomName:{text:"The Hollow",color:"dark_red"},Health:80.0f,attributes:[{id:"minecraft:max_health",base:80.0d},{id:"minecraft:attack_damage",base:7.0d},{id:"minecraft:movement_speed",base:0.38d},{id:"minecraft:follow_range",base:64.0d}]}
playsound minecraft:entity.warden.nearby_closest ambient @s ~ ~ ~ 2 0.5
tellraw @s {text:"<???> i found you",color:"dark_red"}
