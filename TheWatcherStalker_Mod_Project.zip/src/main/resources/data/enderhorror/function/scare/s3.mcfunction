effect give @s minecraft:darkness 10 0
playsound minecraft:entity.warden.heartbeat ambient @s ~ ~ ~ 2 1
playsound minecraft:entity.warden.nearby_close ambient @s ~ ~ ~ 1.5 0.8
