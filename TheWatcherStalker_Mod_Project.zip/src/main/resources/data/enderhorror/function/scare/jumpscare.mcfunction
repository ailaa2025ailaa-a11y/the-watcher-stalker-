title @s times 0 14 8
title @s title {text:"\ue001",font:"enderhorror:jump"}
playsound minecraft:entity.ghast.scream master @s ~ ~ ~ 2 0.6
playsound minecraft:entity.enderman.scream master @s ~ ~ ~ 2 0.5
effect give @s minecraft:darkness 4 0
