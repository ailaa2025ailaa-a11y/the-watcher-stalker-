scoreboard players set #level eh_level 3
tellraw @s {text:"Horror level: HIGH (very scary!)",color:"red"}
