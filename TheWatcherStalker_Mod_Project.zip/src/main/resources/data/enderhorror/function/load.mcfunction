scoreboard objectives add eh_level dummy
scoreboard objectives add eh_r dummy
scoreboard objectives add eh_life dummy
scoreboard objectives add eh_msg dummy
scoreboard objectives add eh_beat dummy
execute unless score #level eh_level matches 0..3 run scoreboard players set #level eh_level 2
